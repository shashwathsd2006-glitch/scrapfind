import { Sparkles, Brain, Shield } from 'lucide-react';

export function Header() {
  return (
    <header className="border-b border-slate-200/60 bg-white/95 backdrop-blur-md sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-5 max-w-7xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 shadow-xl">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-400 to-purple-400 opacity-0 group-hover:opacity-100 transition-opacity blur-xl"></div>
              <Brain className="w-8 h-8 text-white relative z-10" />
            </div>
            <div>
              <h1 className="flex items-center gap-2">
                <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Smart Marketing Assistant
                </span>
                <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
              </h1>
              <p className="text-sm text-slate-600">Enterprise-Grade AI-Powered B2B Business Intelligence</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl shadow-sm">
              <Shield className="w-4 h-4 text-emerald-600" />
              <span className="text-sm text-emerald-700">Secure Analysis</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl shadow-sm">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-blue-700">AI System Active</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { CheckCircle2, Loader2, Brain } from 'lucide-react';

export function AnalysisProgress() {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const steps = [
    { label: 'Establishing Secure Connection', duration: 800 },
    { label: 'Analyzing Website Architecture', duration: 700 },
    { label: 'Extracting Service Intelligence', duration: 900 },
    { label: 'Identifying Target Demographics', duration: 600 },
    { label: 'Generating Strategic Insights', duration: 1000 }
  ];

  useEffect(() => {
    let totalTime = 0;
    const totalDuration = steps.reduce((acc, step) => acc + step.duration, 0);

    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = Math.min(prev + 1, 100);
        return newProgress;
      });
    }, totalDuration / 100);

    const stepTimers = steps.map((step, index) => {
      totalTime += steps.slice(0, index).reduce((acc, s) => acc + s.duration, 0);
      return setTimeout(() => setCurrentStep(index), totalTime);
    });

    return () => {
      clearInterval(timer);
      stepTimers.forEach(clearTimeout);
    };
  }, []);

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="shadow-2xl border-slate-200 bg-gradient-to-br from-white via-blue-50/30 to-purple-50/30 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5"></div>
        <CardHeader className="text-center relative z-10 pb-8">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-2xl">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-400 to-purple-400 opacity-50 blur-xl animate-pulse"></div>
              <div className="absolute -inset-2 rounded-full border-4 border-blue-200 animate-ping opacity-20"></div>
            </div>
          </div>
          <CardTitle className="text-slate-900">
            AI Analysis in Progress
          </CardTitle>
          <CardDescription className="text-base mt-2">
            Our advanced artificial intelligence system is conducting a comprehensive analysis of your business
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8 relative z-10">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-slate-700">Processing Status</span>
              <div className="flex items-center gap-3">
                <span className="text-slate-900">{Math.round(progress)}%</span>
                <div className="flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
            <div className="relative">
              <Progress value={progress} className="h-3 bg-slate-200" />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-full opacity-20 blur-sm"></div>
            </div>
          </div>

          <div className="space-y-3">
            {steps.map((step, index) => (
              <div
                key={index}
                className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-500 ${
                  index < currentStep
                    ? 'bg-gradient-to-r from-emerald-50 to-teal-50 border-2 border-emerald-200 shadow-md'
                    : index === currentStep
                    ? 'bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-300 shadow-lg scale-[1.02]'
                    : 'bg-slate-50 border border-slate-200'
                }`}
              >
                <div className="flex-shrink-0">
                  {index < currentStep ? (
                    <div className="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shadow-md">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                  ) : index === currentStep ? (
                    <div className="relative">
                      <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
                      <div className="absolute inset-0 bg-blue-400 blur-md opacity-50 rounded-full"></div>
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full border-2 border-slate-300 bg-white" />
                  )}
                </div>
                <div className="flex-1">
                  <span
                    className={`${
                      index <= currentStep ? 'text-slate-900' : 'text-slate-500'
                    } transition-colors`}
                  >
                    {step.label}
                  </span>
                </div>
                {index === currentStep && (
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse" style={{ animationDelay: '200ms' }}></div>
                    <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '400ms' }}></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

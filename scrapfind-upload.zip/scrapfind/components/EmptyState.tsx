import { Target, Zap, TrendingUp, Users, Sparkles } from 'lucide-react';

export function EmptyState() {
  const features = [
    {
      icon: Target,
      title: 'Service Identification',
      description: 'Precisely identify and categorize core business offerings with advanced AI analysis',
      gradient: 'from-blue-500 to-cyan-500',
      bgGradient: 'from-blue-50 to-cyan-50'
    },
    {
      icon: Users,
      title: 'Audience Intelligence',
      description: 'Discover comprehensive target audience segments and behavioral personas',
      gradient: 'from-purple-500 to-pink-500',
      bgGradient: 'from-purple-50 to-pink-50'
    },
    {
      icon: TrendingUp,
      title: 'Strategic Marketing',
      description: 'Receive data-driven marketing recommendations tailored to your business',
      gradient: 'from-emerald-500 to-teal-500',
      bgGradient: 'from-emerald-50 to-teal-50'
    },
    {
      icon: Zap,
      title: 'Competitive Analysis',
      description: 'Uncover unique differentiators and competitive advantages in your market',
      gradient: 'from-amber-500 to-orange-500',
      bgGradient: 'from-amber-50 to-orange-50'
    }
  ];

  return (
    <div className="text-center space-y-10">
      <div className="space-y-4 relative">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200 rounded-full mb-4">
          <Sparkles className="w-4 h-4 text-blue-600" />
          <span className="text-sm text-blue-700">Next-Generation Business Intelligence</span>
        </div>
        <h2 className="text-slate-900">
          Comprehensive B2B Business Analysis
          <br />
          <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Powered by Advanced AI
          </span>
        </h2>
        <p className="text-slate-600 max-w-2xl mx-auto text-lg">
          Leverage artificial intelligence to extract actionable insights from business websites. Our platform 
          delivers comprehensive analysis of services, target audiences, and strategic marketing recommendations.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 max-w-6xl mx-auto">
        {features.map((feature, index) => (
          <div
            key={index}
            className="group p-6 bg-white rounded-2xl border border-slate-200 hover:border-transparent hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 relative overflow-hidden"
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${feature.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
            <div className="relative z-10">
              <div className={`flex items-center justify-center w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} mb-4 mx-auto shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  CheckCircle2, 
  Globe, 
  Target, 
  TrendingUp, 
  Award,
  ArrowLeft,
  Download,
  Share2,
  Briefcase,
  Users,
  Lightbulb,
  Star
} from 'lucide-react';

interface Service {
  name: string;
  description: string;
  category: string;
  confidence: number;
}

interface MarketingRecommendation {
  channel: string;
  strategy: string;
  priority: 'high' | 'medium' | 'low';
}

interface AnalysisData {
  businessName: string;
  websiteUrl: string;
  description: string;
  services: Service[];
  targetAudience: string[];
  keyDifferentiators: string[];
  marketingRecommendations: MarketingRecommendation[];
  competitiveAdvantages: string[];
  timestamp: string;
}

interface AnalysisResultsProps {
  data: AnalysisData;
  onNewAnalysis: () => void;
  history: AnalysisData[];
}

export function AnalysisResults({ data, onNewAnalysis, history }: AnalysisResultsProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-gradient-to-r from-rose-100 to-red-100 text-red-800 border-red-300 shadow-sm';
      case 'medium':
        return 'bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-800 border-amber-300 shadow-sm';
      case 'low':
        return 'bg-gradient-to-r from-sky-100 to-blue-100 text-blue-800 border-blue-300 shadow-sm';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600';
    if (confidence >= 0.8) return 'text-blue-600';
    return 'text-yellow-600';
  };

  const handleExport = () => {
    const exportData = {
      ...data,
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analysis-${data.businessName.toLowerCase()}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="shadow-2xl border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-cyan-500/5"></div>
        <CardHeader className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shadow-lg">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-slate-900">
                    Comprehensive Analysis Complete
                  </CardTitle>
                  <CardDescription className="flex items-center gap-2 mt-1 text-base">
                    <Globe className="w-4 h-4 text-blue-600" />
                    <span className="text-slate-700">{data.websiteUrl}</span>
                  </CardDescription>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={handleExport} className="border-slate-300 hover:bg-white hover:shadow-md transition-all">
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
              <Button variant="outline" size="sm" className="border-slate-300 hover:bg-white hover:shadow-md transition-all">
                <Share2 className="w-4 h-4 mr-2" />
                Share Results
              </Button>
              <Button onClick={onNewAnalysis} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-md hover:shadow-lg transition-all">
                <ArrowLeft className="w-4 h-4 mr-2" />
                New Analysis
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Main Results */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 p-1.5 bg-gradient-to-r from-slate-100 to-slate-50 border border-slate-200 shadow-md h-auto">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white data-[state=active]:shadow-lg">
            Business Overview
          </TabsTrigger>
          <TabsTrigger value="services" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white data-[state=active]:shadow-lg">
            Service Analysis
          </TabsTrigger>
          <TabsTrigger value="marketing" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-600 data-[state=active]:to-teal-600 data-[state=active]:text-white data-[state=active]:shadow-lg">
            Marketing Strategy
          </TabsTrigger>
          <TabsTrigger value="insights" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-600 data-[state=active]:to-orange-600 data-[state=active]:text-white data-[state=active]:shadow-lg">
            Strategic Insights
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Business Summary */}
            <Card className="shadow-xl border-2 border-blue-200 bg-gradient-to-br from-white to-blue-50/30 hover:shadow-2xl transition-all">
              <CardHeader className="border-b border-blue-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardTitle className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center">
                    <Briefcase className="w-4 h-4 text-white" />
                  </div>
                  Business Profile Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <div>
                  <h4 className="text-slate-900 mb-3">{data.businessName}</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">{data.description}</p>
                </div>
                <Separator className="bg-slate-200" />
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-4 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-xl border border-blue-200 hover:scale-105 transition-transform">
                    <div className="text-blue-700">{data.services.length}</div>
                    <div className="text-xs text-slate-700">Identified Services</div>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-xl border border-emerald-200 hover:scale-105 transition-transform">
                    <div className="text-emerald-700">{data.targetAudience.length}</div>
                    <div className="text-xs text-slate-700">Target Segments</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Target Audience */}
            <Card className="shadow-xl border-2 border-purple-200 bg-gradient-to-br from-white to-purple-50/30 hover:shadow-2xl transition-all">
              <CardHeader className="border-b border-purple-100 bg-gradient-to-r from-purple-50 to-pink-50">
                <CardTitle className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                  Target Audience Demographics
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  {data.targetAudience.map((audience, index) => (
                    <li key={index} className="flex items-start gap-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-100 hover:border-purple-300 hover:shadow-md transition-all">
                      <Target className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-slate-700">{audience}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <Card className="shadow-xl border-2 border-blue-200 bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100 hover:shadow-2xl hover:scale-105 transition-all group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-indigo-400/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <CardContent className="pt-6 relative z-10">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-700 mb-1">Average Confidence</p>
                    <p className="text-blue-900">
                      {Math.round(data.services.reduce((acc, s) => acc + s.confidence, 0) / data.services.length * 100)}%
                    </p>
                  </div>
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg">
                    <Star className="w-7 h-7 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-xl border-2 border-purple-200 bg-gradient-to-br from-purple-100 via-purple-50 to-pink-100 hover:shadow-2xl hover:scale-105 transition-all group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-400/20 to-pink-400/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <CardContent className="pt-6 relative z-10">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-700 mb-1">Strategic Actions</p>
                    <p className="text-purple-900">{data.marketingRecommendations.length}</p>
                  </div>
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center shadow-lg">
                    <Lightbulb className="w-7 h-7 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-xl border-2 border-emerald-200 bg-gradient-to-br from-emerald-100 via-emerald-50 to-teal-100 hover:shadow-2xl hover:scale-105 transition-all group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-teal-400/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <CardContent className="pt-6 relative z-10">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-700 mb-1">Key Advantages</p>
                    <p className="text-emerald-900">{data.competitiveAdvantages.length}</p>
                  </div>
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center shadow-lg">
                    <Award className="w-7 h-7 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Services Tab */}
        <TabsContent value="services" className="space-y-6">
          <Card className="shadow-2xl border-2 border-purple-200 bg-gradient-to-br from-white to-purple-50/20">
            <CardHeader className="border-b border-purple-100 bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                  <Briefcase className="w-4 h-4 text-white" />
                </div>
                Comprehensive Service Analysis
              </CardTitle>
              <CardDescription className="text-base">
                AI-detected services with precision confidence scoring
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {data.services.map((service, index) => (
                  <div
                    key={index}
                    className="group p-5 bg-gradient-to-br from-white to-slate-50 rounded-xl border-2 border-slate-200 hover:border-purple-300 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="text-slate-900">{service.name}</h4>
                          <Badge className="bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 border-purple-300 shadow-sm">
                            {service.category}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600 leading-relaxed">{service.description}</p>
                      </div>
                      <div className="text-right">
                        <div className={`${getConfidenceColor(service.confidence)} text-lg`}>
                          {Math.round(service.confidence * 100)}%
                        </div>
                        <div className="text-xs text-slate-500 uppercase tracking-wider">Confidence</div>
                      </div>
                    </div>
                    <div className="relative w-full bg-slate-200 rounded-full h-2 mt-4 overflow-hidden">
                      <div
                        className="absolute inset-y-0 left-0 bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 rounded-full transition-all duration-1000 shadow-md"
                        style={{ width: `${service.confidence * 100}%` }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-pink-400 opacity-50 blur-sm"></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Marketing Tab */}
        <TabsContent value="marketing" className="space-y-6">
          <Card className="shadow-2xl border-2 border-emerald-200 bg-gradient-to-br from-white to-emerald-50/20">
            <CardHeader className="border-b border-emerald-100 bg-gradient-to-r from-emerald-50 to-teal-50">
              <CardTitle className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-white" />
                </div>
                Strategic Marketing Recommendations
              </CardTitle>
              <CardDescription className="text-base">
                Prioritized strategies designed to optimize your B2B marketing initiatives
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {data.marketingRecommendations.map((rec, index) => (
                  <div
                    key={index}
                    className="group p-5 bg-gradient-to-br from-white to-slate-50 rounded-xl border-2 border-slate-200 hover:border-emerald-300 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <h4 className="text-slate-900">{rec.channel}</h4>
                          <Badge className={`${getPriorityColor(rec.priority)} uppercase tracking-wide text-xs px-3 py-1`}>
                            {rec.priority} priority
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600 leading-relaxed">{rec.strategy}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Key Differentiators */}
            <Card className="shadow-2xl border-2 border-amber-200 bg-gradient-to-br from-white to-amber-50/20 hover:shadow-2xl transition-all">
              <CardHeader className="border-b border-amber-100 bg-gradient-to-r from-amber-50 to-orange-50">
                <CardTitle className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-600 to-orange-600 flex items-center justify-center">
                    <Star className="w-4 h-4 text-white" />
                  </div>
                  Key Market Differentiators
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  {data.keyDifferentiators.map((diff, index) => (
                    <li key={index} className="flex items-start gap-3 p-3 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border border-amber-100 hover:border-amber-300 hover:shadow-md transition-all">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm text-slate-700 leading-relaxed">{diff}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Competitive Advantages */}
            <Card className="shadow-2xl border-2 border-blue-200 bg-gradient-to-br from-white to-blue-50/20 hover:shadow-2xl transition-all">
              <CardHeader className="border-b border-blue-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardTitle className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center">
                    <Award className="w-4 h-4 text-white" />
                  </div>
                  Competitive Market Advantages
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  {data.competitiveAdvantages.map((advantage, index) => (
                    <li key={index} className="flex items-start gap-3 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100 hover:border-blue-300 hover:shadow-md transition-all">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm text-slate-700 leading-relaxed">{advantage}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

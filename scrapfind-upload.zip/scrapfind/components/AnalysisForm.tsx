import { useState } from 'react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Globe, FileText, Sparkles, Lock, Zap } from 'lucide-react';

interface AnalysisFormProps {
  onAnalyze: (description: string, websiteUrl: string) => void;
}

export function AnalysisForm({ onAnalyze }: AnalysisFormProps) {
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [description, setDescription] = useState('');
  const [errors, setErrors] = useState<{ url?: string; description?: string }>({});

  const validateForm = () => {
    const newErrors: { url?: string; description?: string } = {};

    if (!websiteUrl.trim()) {
      newErrors.url = 'Website URL is required for analysis';
    } else if (!isValidUrl(websiteUrl)) {
      newErrors.url = 'Please provide a valid website URL';
    }

    if (!description.trim()) {
      newErrors.description = 'Business description is required for comprehensive analysis';
    } else if (description.trim().length < 20) {
      newErrors.description = 'Please provide a more detailed description (minimum 20 characters)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (url: string) => {
    try {
      new URL(url.startsWith('http') ? url : `https://${url}`);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      const formattedUrl = websiteUrl.startsWith('http') ? websiteUrl : `https://${websiteUrl}`;
      onAnalyze(description, formattedUrl);
    }
  };

  const handleQuickFill = () => {
    setWebsiteUrl('https://example-saas.com');
    setDescription('We provide cloud-based enterprise software solutions for B2B companies, specializing in CRM, marketing automation, and data analytics. Our platform helps businesses streamline operations and increase productivity through innovative technology solutions.');
  };

  return (
    <Card className="max-w-4xl mx-auto shadow-2xl border-slate-200 bg-gradient-to-br from-white to-slate-50">
      <CardHeader className="space-y-3 pb-6">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Initiate Business Analysis
            </span>
            <Sparkles className="w-6 h-6 text-amber-500" />
          </CardTitle>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg">
            <Lock className="w-3.5 h-3.5 text-green-600" />
            <span className="text-xs text-green-700">Secure</span>
          </div>
        </div>
        <CardDescription className="text-base">
          Provide your business information to receive comprehensive, AI-driven insights and strategic recommendations
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-3">
            <Label htmlFor="website-url" className="flex items-center gap-2 text-slate-700">
              <Globe className="w-4 h-4 text-blue-600" />
              Business Website URL
            </Label>
            <Input
              id="website-url"
              type="text"
              placeholder="https://www.yourbusiness.com"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              className={`h-12 text-base transition-all ${errors.url ? 'border-red-500 focus-visible:ring-red-500' : 'focus-visible:ring-blue-500 border-slate-300'}`}
            />
            {errors.url && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-700">{errors.url}</p>
              </div>
            )}
          </div>

          <div className="space-y-3">
            <Label htmlFor="description" className="flex items-center gap-2 text-slate-700">
              <FileText className="w-4 h-4 text-indigo-600" />
              Comprehensive Business Description
            </Label>
            <Textarea
              id="description"
              placeholder="Provide a detailed description of your B2B business, including your core services, target market segments, unique value propositions, and competitive positioning..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={7}
              className={`text-base transition-all resize-none ${errors.description ? 'border-red-500 focus-visible:ring-red-500' : 'focus-visible:ring-indigo-500 border-slate-300'}`}
            />
            <div className="flex items-center justify-between px-1">
              {errors.description ? (
                <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg flex-1">
                  <p className="text-sm text-red-700">{errors.description}</p>
                </div>
              ) : (
                <p className="text-sm text-slate-500">
                  {description.length} characters • Minimum 20 required for optimal analysis
                </p>
              )}
            </div>
          </div>

          <div className="pt-4 space-y-3">
            <Button 
              type="submit" 
              className="w-full h-13 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Zap className="w-5 h-5 mr-2" />
              Commence AI-Powered Analysis
            </Button>
            <Button 
              type="button" 
              variant="outline"
              onClick={handleQuickFill}
              className="w-full h-12 border-slate-300 hover:bg-slate-50 hover:border-slate-400 transition-all"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Load Demonstration Example
            </Button>
          </div>

          <div className="flex items-center justify-center gap-6 pt-2 pb-2 text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Secure Processing</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>Real-time Analysis</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span>Confidential Data</span>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

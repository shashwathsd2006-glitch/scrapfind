# ScrapFind - Live Preview Options

## 🚀 Quick Start Options

### Option 1: Local Development (Full Features)
```bash
# Install Node.js from https://nodejs.org/ first
npm install
npm run dev
# Open http://localhost:5173
```

### Option 2: Deploy to Vercel (1-Click)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone)

1. Visit [vercel.com](https://vercel.com)
2. Click "Add New" → "Project"
3. Import this folder or GitHub repository
4. Click "Deploy"
5. Your app will be live in seconds!

### Option 3: StackBlitz (Instant Browser Preview)
1. Visit [stackblitz.com](https://stackblitz.com)
2. Click "New Project" → "Import from GitHub" OR drag this folder
3. Your app runs instantly in the browser!

## 📋 Requirements

- **Backend**: Requires Perplexity API key (set in `.env` as `VITE_PERPLEXITY_API_KEY`)
- **Node.js**: v18+ required for local development
- **Browser**: Modern browser (Chrome, Safari, Firefox, Edge)

## 🔧 Environment Setup

Create a `.env` file:
```
VITE_PERPLEXITY_API_KEY=your-api-key-here
```

## 📦 Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **UI**: Tailwind CSS + Radix UI
- **Backend**: Express.js (Node server on port 3001)
- **AI**: Perplexity API for business analysis

# 🔍 ScrapFind - B2B Service Analysis Platform

AI-powered business analysis tool that discovers comprehensive insights about any B2B company's services, target audience, and marketing strategies.

## 🚀 Quick Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone)

### Deployment Steps:

1. **Visit [vercel.com](https://vercel.com)** and sign up (free)
2. Click **"Add New"** → **"Project"**
3. Click **"Import Git Repository"** or drag this folder
4. **Configure Environment Variables:**
   - Add `VITE_PERPLEXITY_API_KEY` with your Perplexity API key
5. Click **"Deploy"**
6. Your app will be live in ~60 seconds! 🎉

### Get Your API Key:
- Sign up at [Perplexity API](https://www.perplexity.ai/settings/api)
- Copy your API key
- Add it as `VITE_PERPLEXITY_API_KEY` in Vercel environment variables

## 💻 Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + Radix UI
- **Routing**: React Router v7
- **Icons**: Lucide React
- **AI**: Perplexity API
- **Backend**: Express.js (Node.js)

## 📁 Project Structure

```
/src
  /components     # React components
    /ui          # Radix UI wrappers
  /pages         # Page components
  /services      # API services
  App.tsx        # Main app component
  main.tsx       # Entry point
```

## 🔑 Environment Variables

Create a `.env` file:

```env
VITE_PERPLEXITY_API_KEY=your-perplexity-api-key
```

## 📦 Features

- ✅ AI-powered business analysis
- ✅ Service discovery and categorization
- ✅ Target audience identification
- ✅ Marketing strategy recommendations
- ✅ Competitive advantage analysis
- ✅ Real-time website scraping
- ✅ Beautiful, responsive UI

## 🌐 Deploy

This project is optimized for Vercel deployment with automatic builds and previews.

## 📄 License

MIT License - feel free to use for your projects!

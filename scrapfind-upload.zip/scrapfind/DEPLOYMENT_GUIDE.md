# 🚀 Vercel Deployment Guide for ScrapFind

## Step-by-Step Deployment Instructions

### Option A: Direct Vercel Deployment (Easiest - 5 minutes)

#### 1. **Prepare Your Project**
   - ✅ All files are ready in `/Users/shashwathsduvani/Downloads/scrapfind`
   - ✅ `vercel.json` configuration is set up
   - ✅ `.gitignore` is configured

#### 2. **Sign Up for Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click **"Sign Up"** (free account)
   - Sign up with GitHub, GitLab, or Email

#### 3. **Deploy Your Project**

   **Method 1: Upload via Web Interface**
   1. Log into [vercel.com/dashboard](https://vercel.com/dashboard)
   2. Click **"Add New..."** → **"Project"**
   3. Click **"Browse"** and select your project folder
   4. Or drag and drop the `/Users/shashwathsduvani/Downloads/scrapfind` folder

   **Method 2: Via Git Repository (Recommended)**
   1. Initialize Git in your project:
      ```bash
      cd /Users/shashwathsduvani/Downloads/scrapfind
      git init
      git add .
      git commit -m "Initial commit"
      ```
   2. Create a new repository on GitHub
   3. Push your code:
      ```bash
      git remote add origin YOUR_GITHUB_REPO_URL
      git branch -M main
      git push -u origin main
      ```
   4. Go to [vercel.com/new](https://vercel.com/new)
   5. Click **"Import Git Repository"**
   6. Select your repository
   7. Click **"Import"**

#### 4. **Configure Environment Variables**
   Before deploying, add your API key:
   
   1. In the Vercel dashboard, go to your project settings
   2. Click **"Environment Variables"**
   3. Add the following:
      - **Name**: `VITE_PERPLEXITY_API_KEY`
      - **Value**: Your Perplexity API key
      - **Environment**: Production, Preview, Development (select all)
   4. Click **"Save"**

#### 5. **Deploy!**
   1. Click **"Deploy"**
   2. Wait ~60 seconds for build to complete
   3. Your app will be live! 🎉
   4. You'll get a URL like: `https://scrapfind-xxx.vercel.app`

---

### Option B: Using Vercel CLI (Advanced)

#### 1. **Install Vercel CLI**
   First, install Node.js from [nodejs.org](https://nodejs.org/), then:
   ```bash
   npm install -g vercel
   ```

#### 2. **Login to Vercel**
   ```bash
   vercel login
   ```

#### 3. **Deploy**
   ```bash
   cd /Users/shashwathsduvani/Downloads/scrapfind
   vercel
   ```
   
   Follow the prompts:
   - Set up and deploy? **Yes**
   - Which scope? **Your account**
   - Link to existing project? **No**
   - What's your project's name? **scrapfind** (or your choice)
   - In which directory is your code located? **./** 
   - Want to override settings? **No**

#### 4. **Set Environment Variables via CLI**
   ```bash
   vercel env add VITE_PERPLEXITY_API_KEY
   ```
   Paste your API key when prompted.

#### 5. **Deploy to Production**
   ```bash
   vercel --prod
   ```

---

## 🔑 Getting Your Perplexity API Key

1. Go to [Perplexity AI](https://www.perplexity.ai/)
2. Sign up or log in
3. Navigate to **Settings** → **API**
4. Generate a new API key
5. Copy the key (it starts with `pplx-...`)
6. Add it to Vercel environment variables

---

## 📊 After Deployment

### Your Live App Will Include:
- ✅ Live URL (e.g., `https://scrapfind.vercel.app`)
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Automatic deployments on Git push
- ✅ Preview deployments for branches
- ✅ Analytics and monitoring

### Testing Your Deployment:
1. Visit your Vercel URL
2. Enter a business website (e.g., `https://vercel.com`)
3. Add a description
4. Click **"Analyze Services"**
5. View the AI-powered analysis results!

---

## 🛠️ Troubleshooting

### Build Fails?
- Check that all dependencies are in `package.json`
- Verify Node.js version compatibility
- Check build logs in Vercel dashboard

### API Not Working?
- Verify `VITE_PERPLEXITY_API_KEY` is set correctly
- Check that the key is valid
- Ensure environment variables are set for all environments

### Backend Server Issues?
- The backend (`server.js`) needs to be deployed separately or combined
- Consider using Vercel Serverless Functions (requires restructuring)

---

## 🎯 Quick Links

- **Vercel Dashboard**: [vercel.com/dashboard](https://vercel.com/dashboard)
- **Documentation**: [vercel.com/docs](https://vercel.com/docs)
- **Support**: [vercel.com/support](https://vercel.com/support)

---

## 🎉 Next Steps

After deployment:
1. ✅ Share your live URL
2. ✅ Set up custom domain (optional)
3. ✅ Enable analytics
4. ✅ Configure preview deployments
5. ✅ Set up monitoring

**Your ScrapFind app will be live in minutes!** 🚀

import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { AnalysisForm } from './components/AnalysisForm';
import { AnalysisResults } from './components/AnalysisResults';
import { AnalysisProgress } from './components/AnalysisProgress';
import { Header } from './components/Header';
import { EmptyState } from './components/EmptyState';
import { Pricing } from './pages/Pricing';
import { NotFound } from './pages/NotFound';
import { analyzeWebsiteWithAI } from './services/aiAnalysis';

interface AnalysisData {
  businessName: string;
  websiteUrl: string;
  description: string;
  services: Service[];
  targetAudience: string[];
  keyDifferentiators: string[];
  marketingRecommendations: MarketingRecommendation[];
  competitiveAdvantages: string[];
  timestamp: string;
}

interface Service {
  name: string;
  description: string;
  category: string;
  confidence: number;
}

interface MarketingRecommendation {
  channel: string;
  strategy: string;
  priority: 'high' | 'medium' | 'low';
}

export default function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null);
  const [analysisHistory, setAnalysisHistory] = useState<AnalysisData[]>([]);

  const handleAnalyze = async (businessDescription: string, websiteUrl: string) => {
    setIsAnalyzing(true);
    setAnalysisData(null);

    try {
      console.log('🚀 Starting OpenAI analysis...');
      
      const aiResult = await analyzeWebsiteWithAI(websiteUrl, businessDescription);
      console.log('✅ AI Analysis Result:', aiResult);

      const results: AnalysisData = {
        businessName: aiResult.businessName,
        websiteUrl,
        description: aiResult.description,
        services: aiResult.services,
        targetAudience: aiResult.targetAudience,
        keyDifferentiators: aiResult.keyDifferentiators,
        marketingRecommendations: aiResult.marketingRecommendations,
        competitiveAdvantages: aiResult.competitiveAdvantages,
        timestamp: new Date().toISOString(),
      };

      setAnalysisData(results);
      setAnalysisHistory(prev => [results, ...prev]);
    } catch (error: any) {
      console.error('❌ Analysis error:', error);
      alert(`Analysis Failed: ${error.message}

Please ensure you have:
1. Added your OpenAI API key to .env file
2. Set VITE_OPENAI_API_KEY=your-key
3. Restarted the development server`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleNewAnalysis = () => {
    setAnalysisData(null);
  };

  return (
    <Routes>
      <Route path="/" element={
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 via-purple-50/30 to-indigo-50 relative">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Q0EzQUYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE4YzMuMzEgMCA2LTIuNjkgNi02cy0yLjY5LTYtNi02LTYgMi42OS02IDYgMi42OSA2IDYgNm0tMTIgMGMzLjMxIDAgNi0yLjY5IDYtNnMtMi42OS02LTYtNi02IDIuNjktNiA2IDIuNjkgNiA2IDZtMTIgMTJjMy4zMSAwIDYtMi42OSA2LTZzLTIuNjktNi02LTYtNiAyLjY5LTYgNiAyLjY5IDYgNiA2bS0xMiAwYzMuMzEgMCA2LTIuNjkgNi02cy0yLjY5LTYtNi02LTYgMi42OS02IDYgMi42OSA2IDYgNiIvPjwvZz48L2c+PC9zdmc+')] opacity-40"></div>
          <Header />
          
          <main className="container mx-auto px-4 py-10 max-w-7xl relative z-10">
            {!isAnalyzing && !analysisData && (
              <div className="space-y-10">
                <EmptyState />
                <AnalysisForm onAnalyze={handleAnalyze} />
              </div>
            )}

            {isAnalyzing && <AnalysisProgress />}

            {analysisData && !isAnalyzing && (
              <AnalysisResults 
                data={analysisData} 
                onNewAnalysis={handleNewAnalysis}
                history={analysisHistory}
              />
            )}
          </main>
        </div>
      } />
      <Route path="/pricing" element={<Pricing />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

// Helper function to fetch detailed website content for intelligent analysis
async function fetchWebsiteDataWithContent(url: string) {
  try {
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
    const response = await fetch(proxyUrl, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    
    const data = await response.json();
    const htmlContent = data.contents;
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    
    const title = doc.querySelector('title')?.textContent?.trim() || extractBusinessName(url);
    const description = doc.querySelector('meta[name="description"]')?.getAttribute('content')?.trim() || '';
    const headings = Array.from(doc.querySelectorAll('h1, h2, h3, h4')).map(h => h.textContent?.trim() || '').filter(Boolean);
    const paragraphs = Array.from(doc.querySelectorAll('p')).map(p => p.textContent?.trim() || '').filter(Boolean);
    const links = Array.from(doc.querySelectorAll('a')).map(a => a.textContent?.trim() || '').filter(Boolean);
    const allText = doc.body?.textContent?.toLowerCase() || '';
    
    return { title, description, headings, paragraphs, links, allText };
  } catch (error) {
    console.warn('Failed to fetch detailed content:', error);
    const title = extractBusinessName(url);
    return {
      title,
      description: `${title} business website`,
      headings: [],
      paragraphs: [],
      links: [],
      allText: ''
    };
  }
}

// Helper function to fetch real website data
async function fetchWebsiteData(url: string): Promise<{
  title: string | null;
  description: string | null;
  keywords: string[];
  services: Array<{ name: string; description: string; category: string; confidence: number }>;
}> {
  console.log('🔍 Fetching real website data from:', url);
  
  try {
    // Try to fetch the actual website using a CORS proxy
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
    const response = await fetch(proxyUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch website');
    }
    
    const data = await response.json();
    const htmlContent = data.contents;
    
    // Parse the HTML to extract metadata
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    
    // Extract title
    const title = doc.querySelector('title')?.textContent?.trim() ||
                  doc.querySelector('meta[property="og:title"]')?.getAttribute('content')?.trim() ||
                  doc.querySelector('h1')?.textContent?.trim() ||
                  extractBusinessName(url);
    
    // Extract description
    const description = doc.querySelector('meta[name="description"]')?.getAttribute('content')?.trim() ||
                       doc.querySelector('meta[property="og:description"]')?.getAttribute('content')?.trim() ||
                       doc.querySelector('p')?.textContent?.trim() ||
                       `${title} - Business website`;
    
    // Extract ALL text content from the page
    const bodyText = doc.body?.textContent?.toLowerCase() || '';
    const headings = Array.from(doc.querySelectorAll('h1, h2, h3, h4')).map(h => h.textContent?.toLowerCase() || '').join(' ');
    const links = Array.from(doc.querySelectorAll('a')).map(a => a.textContent?.toLowerCase() || '').join(' ');
    const paragraphs = Array.from(doc.querySelectorAll('p')).map(p => p.textContent?.toLowerCase() || '').join(' ');
    const listItems = Array.from(doc.querySelectorAll('li')).map(li => li.textContent?.toLowerCase() || '').join(' ');
    
    const allText = (bodyText + ' ' + headings + ' ' + links + ' ' + paragraphs + ' ' + listItems).toLowerCase();
    
    // Extract real services from the page
    const extractedServices: Array<{ name: string; description: string; category: string; confidence: number }> = [];
    
    // Look for service-related sections
    const serviceKeywords = ['services', 'solutions', 'products', 'offerings', 'what we do', 'features', 'capabilities'];
    const serviceSections = Array.from(doc.querySelectorAll('section, div, article')).filter(section => {
      const sectionText = section.textContent?.toLowerCase() || '';
      return serviceKeywords.some(keyword => sectionText.includes(keyword));
    });
    
    // Extract service names from headings near service keywords
    const allHeadings = Array.from(doc.querySelectorAll('h1, h2, h3, h4, h5, h6'));
    allHeadings.forEach(heading => {
      const headingText = heading.textContent?.trim() || '';
      const headingLower = headingText.toLowerCase();
      
      // Skip generic headings
      if (headingText.length < 5 || headingText.length > 100) return;
      if (headingLower.includes('about') || headingLower.includes('contact') || headingLower.includes('home')) return;
      
      // Look for service indicators
      const serviceIndicators = [
        'service', 'solution', 'platform', 'product', 'tool', 'system', 
        'software', 'app', 'api', 'integration', 'consulting', 'support',
        'management', 'development', 'design', 'marketing', 'analytics',
        'optimization', 'automation', 'cloud', 'hosting', 'security'
      ];
      
      const hasServiceIndicator = serviceIndicators.some(indicator => headingLower.includes(indicator));
      
      if (hasServiceIndicator && headingText.length > 0) {
        // Try to find description nearby
        let description = '';
        let nextElement = heading.nextElementSibling;
        if (nextElement?.tagName === 'P') {
          description = nextElement.textContent?.trim().substring(0, 150) || '';
        }
        
        // Determine category
        let category = 'Services';
        if (headingLower.includes('tech') || headingLower.includes('software') || headingLower.includes('dev')) category = 'Technology';
        else if (headingLower.includes('market') || headingLower.includes('advertis')) category = 'Marketing';
        else if (headingLower.includes('design') || headingLower.includes('creative')) category = 'Design';
        else if (headingLower.includes('consult') || headingLower.includes('advisory')) category = 'Consulting';
        else if (headingLower.includes('data') || headingLower.includes('analytic')) category = 'Analytics';
        else if (headingLower.includes('cloud') || headingLower.includes('host')) category = 'Infrastructure';
        
        if (!extractedServices.some(s => s.name.toLowerCase() === headingText.toLowerCase())) {
          extractedServices.push({
            name: headingText,
            description: description || `Professional ${headingText.toLowerCase()} services`,
            category,
            confidence: 0.85
          });
        }
      }
    });
    
    // Comprehensive keyword detection for fallback
    const keywordCategories = {
      software: ['software', 'saas', 'platform', 'application', 'app', 'code', 'programming', 'developer'],
      tech: ['technology', 'tech', 'innovation', 'digital', 'computer', 'IT', 'information technology'],
      development: ['development', 'developer', 'dev', 'build', 'create', 'engineer', 'engineering'],
      cloud: ['cloud', 'aws', 'azure', 'gcp', 'hosting', 'infrastructure', 'server'],
      design: ['design', 'designer', 'creative', 'ui', 'ux', 'interface', 'experience', 'visual'],
      marketing: ['marketing', 'advertis', 'campaign', 'brand', 'promotion', 'seo', 'sem'],
      consulting: ['consult', 'advisory', 'advisor', 'expert', 'professional services'],
      analytics: ['analytics', 'data', 'insights', 'reporting', 'metrics', 'tracking'],
      ecommerce: ['ecommerce', 'e-commerce', 'shop', 'store', 'cart', 'payment', 'checkout'],
      automation: ['automation', 'workflow', 'integration', 'api'],
    };
    
    const detectedKeywords: string[] = [];
    
    for (const [category, terms] of Object.entries(keywordCategories)) {
      for (const term of terms) {
        if (allText.includes(term)) {
          if (!detectedKeywords.includes(category)) {
            detectedKeywords.push(category);
          }
          break;
        }
      }
    }
    
    console.log('✅ Successfully extracted:', { 
      title, 
      description, 
      keywords: detectedKeywords,
      services: extractedServices.length
    });
    
    return {
      title,
      description,
      keywords: detectedKeywords.length > 0 ? detectedKeywords : ['business', 'professional', 'services'],
      services: extractedServices
    };
    
  } catch (error) {
    console.warn('⚠️ Could not fetch website, using domain analysis:', error);
    
    // Fallback to domain-based analysis
    const domain = extractDomainKeywords(url);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      title: domain.companyName,
      description: `${domain.companyName} provides professional ${domain.keywords.join(', ')} services`,
      keywords: domain.keywords,
      services: []
    };
  }
}

// Extract keywords from domain name
function extractDomainKeywords(url: string): {
  companyName: string;
  keywords: string[];
} {
  try {
    const domain = new URL(url).hostname.replace('www.', '').toLowerCase();
    const companyName = domain.split('.')[0];
    
    // Keyword mapping based on common domain patterns
    const keywordMap: Record<string, string[]> = {
      // Tech companies
      'vercel': ['software', 'cloud', 'development'],
      'netlify': ['software', 'cloud', 'development'],
      'github': ['software', 'development', 'tech'],
      'gitlab': ['software', 'development', 'tech'],
      'aws': ['cloud', 'tech', 'enterprise'],
      'azure': ['cloud', 'tech', 'enterprise'],
      'google': ['tech', 'cloud', 'software'],
      // Design
      'figma': ['design', 'creative', 'software'],
      'canva': ['design', 'creative', 'marketing'],
      'dribbble': ['design', 'creative'],
      // Marketing
      'hubspot': ['marketing', 'saas', 'software'],
      'mailchimp': ['marketing', 'email', 'automation'],
      'semrush': ['marketing', 'seo', 'analytics'],
      // Consulting
      'mckinsey': ['consulting', 'strategy', 'enterprise'],
      'bain': ['consulting', 'strategy', 'enterprise'],
      'deloitte': ['consulting', 'strategy', 'enterprise'],
    };
    
    // Check if domain matches known companies
    for (const [key, keywords] of Object.entries(keywordMap)) {
      if (domain.includes(key)) {
        return {
          companyName: key.charAt(0).toUpperCase() + key.slice(1),
          keywords
        };
      }
    }
    
    // Infer from domain name
    const inferredKeywords: string[]  = [];
    if (domain.includes('tech') || domain.includes('soft') || domain.includes('dev')) {
      inferredKeywords.push('software', 'tech', 'development');
    }
    if (domain.includes('market') || domain.includes('seo') || domain.includes('ad')) {
      inferredKeywords.push('marketing', 'digital', 'advertising');
    }
    if (domain.includes('design') || domain.includes('creative') || domain.includes('studio')) {
      inferredKeywords.push('design', 'creative', 'agency');
    }
    if (domain.includes('consult') || domain.includes('strategy') || domain.includes('advisory')) {
      inferredKeywords.push('consulting', 'strategy', 'advisory');
    }
    if (domain.includes('cloud') || domain.includes('host') || domain.includes('server')) {
      inferredKeywords.push('cloud', 'tech', 'enterprise');
    }
    if (domain.includes('data') || domain.includes('analytic')) {
      inferredKeywords.push('analytics', 'data', 'intelligence');
    }
    
    // Default keywords if nothing matches
    if (inferredKeywords.length === 0) {
      inferredKeywords.push('business', 'services', 'professional');
    }
    
    return {
      companyName: companyName.charAt(0).toUpperCase() + companyName.slice(1),
      keywords: inferredKeywords
    };
  } catch {
    return {
      companyName: 'Business',
      keywords: ['business', 'services']
    };
  }
}

// Helper functions to generate mock data
function extractBusinessName(url: string): string {
  try {
    const domain = new URL(url).hostname.replace('www.', '');
    const name = domain.split('.')[0];
    return name.charAt(0).toUpperCase() + name.slice(1);
  } catch {
    return 'Business';
  }
}

function generateMockServices(description: string, websiteData: { keywords: string[]; services?: Array<{ name: string; description: string; category: string; confidence: number }> } | null): Service[] {
  // First, check if we have extracted services from the website
  if (websiteData?.services && websiteData.services.length > 0) {
    console.log('🎯 Using extracted services from website:', websiteData.services.length);
    return websiteData.services;
  }
  
  // Fallback to keyword-based generation
  const keywords = description.toLowerCase();
  const webKeywords = websiteData?.keywords || [];
  const allKeywords = keywords + ' ' + webKeywords.join(' ');
  const services: Service[] = [];

  // Technology & Software Services
  if (allKeywords.includes('software') || allKeywords.includes('saas') || allKeywords.includes('tech') || allKeywords.includes('development')) {
    services.push(
      { name: 'Cloud Solutions', description: 'Enterprise cloud infrastructure and migration services', category: 'Technology', confidence: 0.95 },
      { name: 'Software Development', description: 'Custom software development and integration', category: 'Technology', confidence: 0.92 },
      { name: 'API Integration', description: 'Third-party API integration and custom API development', category: 'Technology', confidence: 0.89 },
      { name: 'DevOps Services', description: 'CI/CD pipeline setup and infrastructure automation', category: 'Technology', confidence: 0.88 },
      { name: 'Technical Consulting', description: 'Strategic technology consulting and advisory', category: 'Consulting', confidence: 0.87 }
    );
  }

  // Marketing & Advertising Services
  if (allKeywords.includes('marketing') || allKeywords.includes('advertising') || allKeywords.includes('agency') || allKeywords.includes('digital')) {
    services.push(
      { name: 'Digital Marketing', description: 'Full-service digital marketing campaigns', category: 'Marketing', confidence: 0.94 },
      { name: 'Content Strategy', description: 'Content creation and strategic planning', category: 'Marketing', confidence: 0.91 },
      { name: 'SEO Optimization', description: 'Search engine optimization and organic traffic growth', category: 'Marketing', confidence: 0.90 },
      { name: 'Social Media Management', description: 'Social media strategy and community engagement', category: 'Marketing', confidence: 0.88 },
      { name: 'PPC Advertising', description: 'Pay-per-click campaign management and optimization', category: 'Marketing', confidence: 0.87 },
      { name: 'Email Marketing', description: 'Email campaign design, automation, and analytics', category: 'Marketing', confidence: 0.85 }
    );
  }

  // Consulting & Strategy Services
  if (allKeywords.includes('consulting') || allKeywords.includes('advisory') || allKeywords.includes('strategy')) {
    services.push(
      { name: 'Business Strategy', description: 'Strategic planning and business transformation', category: 'Consulting', confidence: 0.93 },
      { name: 'Management Consulting', description: 'Operational excellence and management advisory', category: 'Consulting', confidence: 0.90 },
      { name: 'Change Management', description: 'Organizational change and transformation support', category: 'Consulting', confidence: 0.87 },
      { name: 'Process Optimization', description: 'Business process analysis and improvement', category: 'Consulting', confidence: 0.85 }
    );
  }

  // Design & Creative Services
  if (allKeywords.includes('design') || allKeywords.includes('creative')) {
    services.push(
      { name: 'UI/UX Design', description: 'User interface and experience design services', category: 'Design', confidence: 0.91 },
      { name: 'Brand Design', description: 'Brand identity and visual design', category: 'Design', confidence: 0.88 },
      { name: 'Web Design', description: 'Responsive website design and development', category: 'Design', confidence: 0.87 },
      { name: 'Graphic Design', description: 'Marketing collateral and visual asset creation', category: 'Design', confidence: 0.85 }
    );
  }

  // Analytics & Data Services
  if (allKeywords.includes('analytics') || allKeywords.includes('data')) {
    services.push(
      { name: 'Data Analytics', description: 'Business intelligence and data analysis', category: 'Analytics', confidence: 0.90 },
      { name: 'Performance Tracking', description: 'KPI tracking and performance monitoring', category: 'Analytics', confidence: 0.86 },
      { name: 'Reporting & Insights', description: 'Custom dashboards and analytics reporting', category: 'Analytics', confidence: 0.84 }
    );
  }

  // E-commerce Services
  if (allKeywords.includes('ecommerce') || allKeywords.includes('commerce') || allKeywords.includes('shop')) {
    services.push(
      { name: 'E-commerce Solutions', description: 'Online store setup and optimization', category: 'E-commerce', confidence: 0.92 },
      { name: 'Payment Integration', description: 'Secure payment gateway integration', category: 'E-commerce', confidence: 0.89 },
      { name: 'Inventory Management', description: 'Product catalog and inventory systems', category: 'E-commerce', confidence: 0.86 }
    );
  }

  // Cloud & Hosting Services
  if (allKeywords.includes('cloud') || allKeywords.includes('hosting') || allKeywords.includes('server')) {
    services.push(
      { name: 'Cloud Hosting', description: 'Scalable cloud hosting and infrastructure', category: 'Infrastructure', confidence: 0.93 },
      { name: 'Server Management', description: 'Server maintenance and optimization', category: 'Infrastructure', confidence: 0.88 },
      { name: 'Backup & Security', description: 'Data backup and security solutions', category: 'Infrastructure', confidence: 0.87 }
    );
  }

  // Automation Services
  if (allKeywords.includes('automation') || allKeywords.includes('workflow')) {
    services.push(
      { name: 'Workflow Automation', description: 'Business process automation solutions', category: 'Automation', confidence: 0.89 },
      { name: 'Integration Services', description: 'System integration and data synchronization', category: 'Automation', confidence: 0.86 }
    );
  }

  // If no specific services detected, provide generic B2B services
  if (services.length === 0) {
    services.push(
      { name: 'Professional Services', description: 'Comprehensive B2B professional services', category: 'Services', confidence: 0.85 },
      { name: 'Business Solutions', description: 'Tailored solutions for business challenges', category: 'Services', confidence: 0.82 },
      { name: 'Strategic Planning', description: 'Business planning and growth strategy', category: 'Consulting', confidence: 0.80 },
      { name: 'Client Support', description: 'Dedicated customer success and support', category: 'Support', confidence: 0.78 },
      { name: 'Training & Enablement', description: 'Team training and capability building', category: 'Support', confidence: 0.75 }
    );
  }

  return services;
}

function generateTargetAudience(description: string, websiteData: { keywords: string[] } | null): string[] {
  const keywords = description.toLowerCase();
  const webKeywords = websiteData?.keywords || [];
  const allKeywords = keywords + ' ' + webKeywords.join(' ');
  const audience: string[] = [];

  if (allKeywords.includes('enterprise') || allKeywords.includes('large')) {
    audience.push('Enterprise Companies (1000+ employees)');
  }
  if (allKeywords.includes('startup') || allKeywords.includes('small')) {
    audience.push('Startups & SMBs (10-500 employees)');
  }
  if (allKeywords.includes('tech') || allKeywords.includes('software')) {
    audience.push('Technology Companies');
  }
  if (allKeywords.includes('agency') || allKeywords.includes('marketing')) {
    audience.push('Marketing & Creative Agencies');
  }
  
  audience.push('C-Level Executives & Decision Makers', 'Department Heads & Managers', 'B2B Service Buyers');
  
  return audience.slice(0, 5);
}

function generateDifferentiators(websiteData: { keywords: string[]; title: string | null } | null): string[] {
  const baseDifferentiators = [
    'Industry-leading expertise with 10+ years experience',
    'Proven ROI with measurable results',
    'Scalable solutions that grow with your business',
    'Dedicated account management and support',
    'Cutting-edge technology and best practices'
  ];

  // Add custom differentiators based on website data
  if (websiteData?.title) {
    baseDifferentiators.unshift(`${websiteData.title} - Trusted by businesses worldwide`);
  }

  return baseDifferentiators.slice(0, 5);
}

function generateRecommendations(websiteData: { keywords: string[] } | null): MarketingRecommendation[] {
  const webKeywords = websiteData?.keywords || [];
  const recommendations: MarketingRecommendation[] = [
    { channel: 'LinkedIn', strategy: 'Thought leadership content and targeted outreach to decision-makers', priority: 'high' },
    { channel: 'Content Marketing', strategy: 'Create in-depth case studies and whitepapers showcasing expertise', priority: 'high' },
    { channel: 'Email Marketing', strategy: 'Nurture campaigns with personalized content for different buyer stages', priority: 'high' },
  ];

  // Add specific recommendations based on website keywords
  if (webKeywords.includes('tech') || webKeywords.includes('software')) {
    recommendations.push(
      { channel: 'Product Hunt', strategy: 'Launch on Product Hunt to reach tech-savvy audience', priority: 'medium' }
    );
  }
  
  if (webKeywords.includes('design') || webKeywords.includes('creative')) {
    recommendations.push(
      { channel: 'Dribbble/Behance', strategy: 'Showcase portfolio and case studies on design platforms', priority: 'medium' }
    );
  }

  recommendations.push(
    { channel: 'SEO', strategy: 'Target high-intent B2B keywords and industry-specific search terms', priority: 'medium' },
    { channel: 'Webinars', strategy: 'Host educational webinars to demonstrate expertise and generate leads', priority: 'medium' },
    { channel: 'Partnerships', strategy: 'Strategic partnerships with complementary B2B service providers', priority: 'low' }
  );

  return recommendations;
}

function generateAdvantages(): string[] {
  return [
    'Established market presence and brand recognition',
    'Comprehensive service offerings',
    'Strong client testimonials and case studies',
    'Experienced team with domain expertise',
    'Flexible engagement models'
  ];
}

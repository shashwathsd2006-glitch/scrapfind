import { useState } from 'react';
import { PricingCard } from '../components/PricingCard';
import { Header } from '../components/Header';

export function Pricing() {
  const [isAnnual, setIsAnnual] = useState(false);

  const starterPrice = isAnnual ? '₹2,490' : '₹249';
  const proPrice = isAnnual ? '₹6,490' : '₹649';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 via-purple-50/30 to-indigo-50">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Q0EzQUYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE4YzMuMzEgMCA2LTIuNjkgNi02cy0yLjY5LTYtNi02LTYgMi42OS02IDYgMi42OSA2IDYgNm0tMTIgMGMzLjMxIDAgNi0yLjY5IDYtNnMtMi42OS02LTYtNi02IDIuNjktNiA2IDIuNjkgNiA2IDZtMTIgMTJjMy4zMSAwIDYtMi42OSA2LTZzLTIuNjktNi02LTYtNiAyLjY5LTYgNiAyLjY5IDYgNiA2bS0xMiAwYzMuMzEgMCA2LTIuNjkgNi02cy0yLjY5LTYtNi02LTYgMi42OS02IDYgMi42OSA2IDYgNiIvPjwvZz48L2c+PC9zdmc+')] opacity-40"></div>
      
      <Header />

      <main className="container mx-auto px-4 py-16 max-w-7xl relative z-10">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Choose the perfect plan for your business analysis needs. 
            No hidden fees, cancel anytime.
          </p>

          {/* Billing Toggle */}
          <div className="inline-flex items-center gap-4 bg-white rounded-full p-1 shadow-md">
            <button
              onClick={() => setIsAnnual(false)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                !isAnnual 
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                isAnnual 
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Annual
              <span className="ml-2 text-xs bg-green-500 text-white px-2 py-0.5 rounded-full">
                Save 17%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Starter Plan */}
          <PricingCard
            name="Starter"
            price={starterPrice}
            period={isAnnual ? 'year' : 'month'}
            description="Perfect for small businesses getting started"
            features={[
              '10 business analyses per month',
              'Basic market insights',
              'Competitor analysis',
              'Email support',
              'Export reports (PDF)',
              '1 user account'
            ]}
            ctaText="Start Free Trial"
            ctaVariant="outline"
          />

          {/* Pro Plan */}
          <PricingCard
            name="Pro"
            price={proPrice}
            period={isAnnual ? 'year' : 'month'}
            description="For growing companies with advanced needs"
            features={[
              'Unlimited business analyses',
              'Advanced AI insights',
              'Deep competitor tracking',
              'Priority support (24/7)',
              'Export reports (PDF, Excel)',
              'Up to 5 user accounts',
              'Custom branding',
              'API access'
            ]}
            ctaText="Get Started"
            isPopular={true}
          />

          {/* Enterprise Plan */}
          <PricingCard
            name="Enterprise"
            price="Custom"
            period=""
            description="Tailored solutions for large organizations"
            features={[
              'Everything in Pro',
              'Unlimited users',
              'Dedicated account manager',
              'Custom integrations',
              'White-label solutions',
              'SLA guarantee',
              'Training & onboarding',
              'Custom data retention'
            ]}
            ctaText="Contact Sales"
            ctaVariant="outline"
          />
        </div>

        {/* FAQ Section */}
        <div className="mt-20 max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-10">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6 bg-white rounded-2xl p-8 shadow-lg">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Can I change plans later?
              </h3>
              <p className="text-gray-600">
                Yes! You can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What payment methods do you accept?
              </h3>
              <p className="text-gray-600">
                We accept all major credit cards, PayPal, and wire transfers for Enterprise plans.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Is there a free trial?
              </h3>
              <p className="text-gray-600">
                Yes! All plans come with a 14-day free trial. No credit card required to start.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What happens if I exceed my plan limits?
              </h3>
              <p className="text-gray-600">
                We'll notify you when you're approaching your limit. You can upgrade anytime or purchase additional credits.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

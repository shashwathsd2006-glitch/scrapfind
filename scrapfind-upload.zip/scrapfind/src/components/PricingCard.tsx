import { Check } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface PricingCardProps {
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  isPopular?: boolean;
  ctaText: string;
  ctaVariant?: 'default' | 'outline';
}

export function PricingCard({
  name,
  price,
  period,
  description,
  features,
  isPopular = false,
  ctaText,
  ctaVariant = 'default'
}: PricingCardProps) {
  return (
    <div 
      className={`relative rounded-2xl border bg-white p-8 shadow-lg transition-all hover:shadow-xl ${
        isPopular ? 'border-blue-500 ring-2 ring-blue-500 ring-offset-2' : 'border-gray-200'
      }`}
    >
      {isPopular && (
        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          Most Popular
        </Badge>
      )}
      
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-gray-900">{name}</h3>
        <p className="mt-2 text-sm text-gray-600">{description}</p>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-2">
          <span className="text-5xl font-bold text-gray-900">{price}</span>
          {period && <span className="text-gray-600">/{period}</span>}
        </div>
      </div>

      <Button 
        className="w-full mb-6" 
        variant={ctaVariant}
        size="lg"
      >
        {ctaText}
      </Button>

      <div className="space-y-3">
        <p className="text-sm font-semibold text-gray-900">What's included:</p>
        {features.map((feature, index) => (
          <div key={index} className="flex items-start gap-3">
            <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
            <span className="text-sm text-gray-700">{feature}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

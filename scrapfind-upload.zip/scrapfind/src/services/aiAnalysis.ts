interface AnalysisResult {
  businessName: string;
  description: string;
  services: Array<{
    name: string;
    description: string;
    category: string;
    confidence: number;
  }>;
  targetAudience: string[];
  keyDifferentiators: string[];
  marketingRecommendations: Array<{
    channel: string;
    strategy: string;
    priority: 'high' | 'medium' | 'low';
  }>;
  competitiveAdvantages: string[];
}

export async function analyzeWebsiteWithAI(
  websiteUrl: string,
  businessDescription: string
): Promise<AnalysisResult> {
  try {
    console.log('🤖 Sending to backend for Perplexity analysis...');

    const response = await fetch('http://localhost:3001/api/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        websiteUrl,
        businessDescription
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Backend analysis failed');
    }

    const analysis: AnalysisResult = await response.json();
    
    console.log('✅ Analysis complete from backend');
    return analysis;

  } catch (error: any) {
    console.error('❌ Backend API Error:', error);
    
    if (error.message?.includes('Failed to fetch')) {
      throw new Error('Cannot connect to backend server. Please ensure the backend is running on http://localhost:3001');
    }
    
    throw new Error(`AI Analysis failed: ${error.message}`);
  }
}

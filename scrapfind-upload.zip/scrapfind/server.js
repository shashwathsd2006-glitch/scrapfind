import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3001;

// Enable CORS for frontend
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true
}));

app.use(express.json());

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Backend server is running' });
});

// Analysis endpoint
app.post('/api/analyze', async (req, res) => {
  try {
    const { websiteUrl, businessDescription } = req.body;

    if (!websiteUrl || !businessDescription) {
      return res.status(400).json({ 
        error: 'Missing required fields: websiteUrl and businessDescription' 
      });
    }

    console.log('🤖 Analyzing with Perplexity:', websiteUrl);

    const apiKey = process.env.VITE_PERPLEXITY_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ 
        error: 'Perplexity API key not configured on server' 
      });
    }

    const client = new OpenAI({
      apiKey: apiKey,
      baseURL: 'https://api.perplexity.ai'
    });

    const prompt = `Analyze the business at ${websiteUrl}.

Description: ${businessDescription}

Provide a comprehensive B2B marketing analysis in JSON format:
{
  "businessName": "company name",
  "description": "2-3 sentences about the business",
  "services": [{"name": "Service", "description": "desc", "category": "Category", "confidence": 0.9}],
  "targetAudience": ["audience 1", "audience 2"],
  "keyDifferentiators": ["differentiator 1"],
  "marketingRecommendations": [{"channel": "Channel", "strategy": "Strategy", "priority": "high"}],
  "competitiveAdvantages": ["advantage 1"]
}

Return ONLY valid JSON.`;

    const response = await client.chat.completions.create({
      model: 'sonar',
      messages: [
        { role: 'system', content: 'You are a B2B marketing analyst. Return only valid JSON.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 2000
    });

    const result = response.choices[0]?.message?.content;
    
    if (!result) {
      throw new Error('No response from Perplexity');
    }

    // Clean response
    let cleanedText = result.trim();
    if (cleanedText.startsWith('```json')) {
      cleanedText = cleanedText.replace(/^```json\n/, '').replace(/\n```$/, '');
    } else if (cleanedText.startsWith('```')) {
      cleanedText = cleanedText.replace(/^```\n/, '').replace(/\n```$/, '');
    }

    const analysis = JSON.parse(cleanedText);
    
    console.log('✅ Analysis complete');
    res.json(analysis);

  } catch (error) {
    console.error('❌ Analysis error:', error);
    res.status(500).json({ 
      error: error.message || 'Analysis failed'
    });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Backend server running on http://localhost:${PORT}`);
  console.log(`📡 Frontend should connect to http://localhost:${PORT}/api/analyze`);
});

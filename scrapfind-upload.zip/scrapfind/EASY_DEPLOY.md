# 🚀 Deploy ScrapFind to Vercel (No Git Required!)

## Option 1: Direct Upload via Vercel CLI (Easiest!)

### Step 1: Install Xcode Command Line Tools (Required Once)
A popup should have appeared asking to install developer tools. Click **"Install"** and wait for it to complete (~5-10 minutes).

**OR** install manually via terminal:
```bash
xcode-select --install
```

### Step 2: Install Node.js
1. Download from: https://nodejs.org/
2. Install the LTS version (recommended)
3. Restart your terminal

### Step 3: Install Vercel CLI
```bash
npm install -g vercel
```

### Step 4: Deploy!
```bash
cd /Users/shashwathsduvani/Downloads/scrapfind
vercel login
vercel
```

Follow the prompts and your app will be live! 🎉

---

## Option 2: Use GitHub Desktop (No Terminal Required!)

### Step 1: Download GitHub Desktop
- Download from: https://desktop.github.com/
- Install and sign in with your GitHub account (create one if needed)

### Step 2: Create Repository
1. Open GitHub Desktop
2. Click **"File"** → **"Add Local Repository"**
3. Browse to `/Users/shashwathsduvani/Downloads/scrapfind`
4. Click **"Create Repository"** (if prompted)
5. Click **"Publish repository"** button
6. Choose a name (e.g., "scrapfind")
7. Uncheck "Keep this code private" (or keep it private, your choice)
8. Click **"Publish Repository"**

### Step 3: Deploy on Vercel
1. Go to https://vercel.com/new
2. Sign in with GitHub
3. Click **"Import Git Repository"**
4. Select your "scrapfind" repository
5. Click **"Import"**
6. Add environment variable:
   - Name: `VITE_PERPLEXITY_API_KEY`
   - Value: Your API key
7. Click **"Deploy"**

Done! 🚀

---

## Option 3: Manual GitHub Upload (Web Interface)

### Step 1: Create GitHub Repository
1. Go to https://github.com/new
2. Repository name: `scrapfind`
3. Description: "B2B Service Analysis Platform"
4. Click **"Create repository"**

### Step 2: Upload Files
1. On the repository page, click **"uploading an existing file"**
2. Drag and drop ALL files from `/Users/shashwathsduvani/Downloads/scrapfind`
3. Write commit message: "Initial commit"
4. Click **"Commit changes"**

### Step 3: Deploy on Vercel
1. Go to https://vercel.com/new
2. Sign in with GitHub
3. Import your "scrapfind" repository
4. Add environment variable: `VITE_PERPLEXITY_API_KEY`
5. Click **"Deploy"**

---

## 🔑 Don't Forget Your API Key!

Get your Perplexity API key:
1. Visit: https://www.perplexity.ai/settings/api
2. Sign up/login
3. Generate API key
4. Add it to Vercel when deploying

---

## 🎯 Recommended: Option 2 (GitHub Desktop)

GitHub Desktop is the easiest if you don't want to use the terminal. It's a visual interface that handles all the Git commands for you!

**Download here**: https://desktop.github.com/

---

## 💡 Quick Help

**Having issues?** You can also:
- Use Netlify Drop: https://app.netlify.com/drop (just drag the folder!)
- Use Render: https://render.com (similar to Vercel)
- Contact me for more options!

---

Your app will be live at a URL like: `https://scrapfind.vercel.app` 🌐

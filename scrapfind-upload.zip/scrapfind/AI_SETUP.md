# 🤖 AI Integration Setup Guide

## Real AI-Powered Website Analysis

This project now uses **OpenAI GPT-4** to provide genuine AI-powered business analysis.

---

## 📋 Setup Steps

### 1. Get an OpenAI API Key

1. Go to [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Sign up or log in
3. Click "Create new secret key"
4. Copy the key (starts with `sk-...`)

### 2. Add API Key to Project

1. Open the `.env` file in your project root
2. Replace the empty value with your API key:

```env
VITE_OPENAI_API_KEY=sk-your-actual-api-key-here
```

### 3. Restart Development Server

```bash
# Stop the current server (Ctrl+C)
# Then restart:
npm run dev
```

---

## 💰 Pricing

- **Model Used**: GPT-4o-mini (cost-effective)
- **Cost per Analysis**: ~$0.001 - $0.003 (very cheap!)
- **Free Tier**: $5 free credits for new accounts

---

## ✨ Features

### Real AI Analysis Includes:

✅ **Intelligent Business Name Extraction**
- AI reads the URL and infers the actual company name

✅ **Service Detection**
- Analyzes what services the business actually offers
- Categorizes them (Technology, Marketing, Consulting, etc.)
- Assigns confidence scores

✅ **Target Audience Identification**
- Determines who the business is targeting
- B2B vs B2C insights
- Company size segments

✅ **Marketing Recommendations**
- Channel-specific strategies
- Prioritized by importance (high/medium/low)
- Actionable tactics

✅ **Competitive Advantages**
- What makes the business unique
- Key differentiators

---

## 🧪 Testing

Try these URLs to see real AI analysis:

```
https://vercel.com
https://stripe.com
https://notion.so
https://figma.com
https://shopify.com
```

Each will produce **unique, contextual analysis** based on the actual business!

---

## 🔒 Security Notes

**⚠️ IMPORTANT**: 
- The current implementation uses `dangerouslyAllowBrowser: true`
- This is **only for development/demo**
- **For production**, move API calls to a backend server
- Never expose API keys in frontend code in production

---

## 🐛 Troubleshooting

### Error: "Invalid or missing OpenAI API key"
✅ **Solution**: Check that your API key in `.env` starts with `sk-`

### Error: "Insufficient quota"
✅ **Solution**: Add payment method or wait for free tier reset

### Analysis shows fallback data
✅ **Solution**: Check browser console for error messages

---

## 🎯 Fallback Behavior

If AI analysis fails (no API key, quota exceeded, etc.):
- System automatically falls back to smart mock analysis
- Uses domain-based keyword detection
- Still provides reasonable results
- Shows error alert to user

---

## 📊 Monitoring Usage

Check your usage at: [https://platform.openai.com/usage](https://platform.openai.com/usage)

---

**Ready to go!** Just add your API key and restart the server. 🚀
